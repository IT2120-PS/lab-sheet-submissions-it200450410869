setwd("C:\\Users\\User\\OneDriveDocuments\\PS _2Y1S\\Lab 10")

observed_counts <- c(120, 95, 85, 100)

chisq.test(x = observed_counts)
