setwd("C:\\Users\\User\\OneDrive\\Documents\\PS _2Y1S\\IT24100970_lab_6")

#Q1
#i.
#binomial distribution

#ii.
pbinom(46,50,0.85,lower.tail =FALSE)


#Q2
#i.
#number of customer calls per hour

#ii.
#poisson distribution

#iii.
dpois(15,12)